#include <stdio.h>

int main() {

    int userAccount;
    int userPassword;
    int choice;
    char answer;

    int user1Account = 0000; //�w�]�b��
    int user1Password = 0000; //�w�]�K�X
    char user1Food[20] = "Japanese";  //�w�]���n

    void list(FILE*);

    FILE *japanData = fopen("data1.txt", "r");
    FILE *taiwanData = fopen("data2.txt", "r");
    //�����n�J���`
    do {




        printf("Enter your account: \n");
        scanf("%d",&userAccount);
        printf("Enter your passeword: \n");
        scanf("%d",&userPassword);

        if (userAccount == user1Account && userPassword == user1Password) {
            printf("Successful Login! \n\n");
            break;
        }
        else{
            printf("Wrong input \n");
        }

        }while(1);
    //��ﰾ�n�M�q�\����
    do{

        printf("1.Changing Preference\n");
        printf("2.Check Preference\n");
        printf("3.Reservation\n");
        printf("4.Log out\n");
        printf("Which service do you want?\n");

        scanf("%d",&choice);

        switch (choice) {
            case 1:
                printf("What kind of food do you prefer? \n");
                scanf("%s",user1Food);
                printf("Your preference change to %s \n\n",user1Food);
                break;
            case 2:
                printf("Your preference is %s \n\n",user1Food);
                break;
            case 3:
                printf("\nYour preference is %s \n\n",user1Food);
                printf("This restaurant is our recommandation:\n");

                if (user1Food[0]=='J') {
                    list(japanData);
                }
                else if (user1Food[0]=='T'){
                    list(taiwanData);
                }


                printf("\nDo you want to book for restaurants? (Y/N)\n");

                scanf("%s",&answer);

                if (answer == 'Y' || answer == 'y') {
                    printf("Has already called the restaurant for you.......\n");

                }
                else if (answer == 'N' || answer == 'n'){
                    printf("Please try again!\n");

                }
                break;
            case 4:
                printf("Thanks for your using!!\n");
                break;
        }


    }while(choice == 1 || choice == 2);
}
void list(FILE* file){

    char restaurant[100];

    fgets(restaurant, 100, file);

    printf("%s", restaurant);

}
